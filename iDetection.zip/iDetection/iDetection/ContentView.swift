//
//  PhotoPicker.swift
//  iDetection
//
//  Created by Antonio Emanuele Cutarella on 07/12/21.
//

import SwiftUI
import CoreML

struct ContentView: View {
    
    @Environment(\.redactionReasons) private var reasons
    @State private var classificationLabel: String = ""
    @State var showImagePicker: Bool = false
    @State var uiImage: UIImage? = nil
    @State var image: Image? = Image("Ciao")
    
    let model: SqueezeNet = {
        
        do {
            
            let config = MLModelConfiguration()
            return try SqueezeNet(configuration: config)
            
        } catch {
            
            print(error)
            fatalError("Couldn't create SqueezeNet")
            
        }
        
    }()
    
    private func classifyImage() {
        
        let uiImage = image.asUIImage().resizeImageTo(size:CGSize(width: 227, height: 227))
        let buffer = uiImage!.convertToBuffer()
        
        if uiImage != nil && buffer != nil {
            
            let output = try? model.prediction(image: buffer!)
            
            if let output = output {
                print(output)
                let results = output.classLabelProbs.sorted { $0.1 > $1.1 }
                let result = results.map { (key, value) in
                    return "\(key) = \(String(format: "%.2f", value * 100))%"
                }.joined(separator: "\n")
                
                self.classificationLabel = result
            }
        }
    }
    
    struct GrowingButton: ButtonStyle {
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .clipShape(Capsule())
                .scaleEffect(configuration.isPressed ? 1.2 : 1)
                .animation(.easeOut(duration: 0.2), value: configuration.isPressed)
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                VStack {

                    image?.resizable().frame(width: 227, height: 227)
                    
                    Button(action: {
                        self.showImagePicker.toggle()
                    })
                    {
                        Text("Select a Photo to Analyze")
                    }
                    .buttonStyle(GrowingButton())
                    .padding()
                    Button("Analyze your Photo"){
                        classifyImage()
                    }
                    .buttonStyle(GrowingButton())
                    .padding()
                    
                    Text(classificationLabel)
                        .padding()
                        .font(.body)
                    Spacer()
                }
                .sheet(isPresented: $showImagePicker) {
                    ImagePicker(sourceType: .photoLibrary) { image in
                        self.image = Image(uiImage: image)
                    }
                }
            }.navigationBarTitle("Analyze")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
