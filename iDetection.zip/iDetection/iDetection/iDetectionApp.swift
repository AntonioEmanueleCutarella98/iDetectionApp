//
//  iDetectionApp.swift
//  iDetection
//
//  Created by Antonio Emanuele Cutarella on 07/12/21.
//

import SwiftUI

@main
struct iDetectionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
